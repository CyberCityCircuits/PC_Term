PC_Term
David A Ray

V0_01_00 - 08-21-2016

V0_02_00 - 08-21-2016

V0_03_00 - 08-22-2016

V0_04_00 - 08-24-2016

V0_04_01 - 09-19-2016

V0_04_02 - 10-04-2016

V0_04_03 - 10-05-2016

V0_05_00 - 10-08-2016

V0_05_01 - 10-11-2016
***	First fully successful version.
***	Corrected a syntax error that allowed the process to work.

V0_05_02 - 10-19-2016

V0_05_03 - 10-19-2016

V0_05_04 - 10-24-2016

V0_05_05 - 10-28-2016

V0_05_06 - 10-30-2016

V0_05_07 - 11-02-2016

V0.05.08 - 11-14-2016
***	Added compatiblity for Python 3.5

V0.05.09 - 11-15-2016
***	Added logging function.

V0.05.10 - 11-16-2016
***	Updated conatact information.
***	Corrected some syntax errors.
