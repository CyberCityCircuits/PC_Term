Commander Tools
By David A. Ray

Attachments include:
PC_Term 
Ping_CMDR 

All software is original and does not infringe on any copyrights or licenses held by Verifone or any Verifone Authorize Service Company.

Note:  If found inside a .zip file, the .zip file will need to be decompressed in order for the tools  to operate properly.

	PC_Term (Product Code Terminator) is a tool created to erase all product codes from a PLU file from a Sapphire or a Commander.  To use the tool place your store export in the folder marked Put_XMLs_Here and then run the PC_Term.exe tool.  Then use the option to import your backup.  When done use the option to export your backup.  This will create two folders.  The one marked Processed_XMLs is the processed files and the one marked BackUp_XMLs is a backup of the original files.  Both folders are time stamped to be able to distinguish between several different file sets.  The tool also creates a log file for you to look at what was done.  There are now options for changing ID Checks and Food Stamp checks.

	Ping_CMDR is a tool created to check and see if the workstations, Commander, and the Enhanced Zone Router are online during the application install.  It aids in troubleshooting during the process.  There is a timestamp that marks the last time the status of each component changes.  There is also an option to create a text log of the changes as they happen.

Please send any questions or concerns to David Ray.
